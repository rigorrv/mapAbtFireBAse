package com.example.notificacionesfcm;

/**
 * Created by Juned on 1/30/2017.
 */

public class Subject {

    //info inside the buttons on the map
    public String Subject_Name;
    public String Subject_Full_Form;

    public String hourSubj;
    public String distanceSubj;

    //loading latitud and longitud window
    public String Lat_info;
    public String Lng_info;
}
